import md5
import sys
import random
import signal

max_len = 4                 # content with length < max_len has been already tested
index = 198585327            # start index
start_content = '97frd'     # start content

arr_dig = map(lambda x: chr(x), range(ord('0'), ord('0')+10))
arr_lower = map(lambda x: chr(x), range(ord('a'), ord('a')+26))
arr_upper = map(lambda x: chr(x), range(ord('A'), ord('A')+26))
arr = arr_dig + arr_lower + arr_upper
len_arr = len(arr)      # 62

def digToStr(idx):
    content = ''
    while idx >= len_arr:
        content += arr[idx % len_arr]
        idx /= len_arr
    content += arr[idx % len_arr]
    return content

def addOne(list_content):
    i = 0

    while i < len(list_content) and list_content[i] == 'Z':
        list_content[i] = '0'
        i += 1
    if i == len(list_content):
        list_content.append(['0'])
    else:
        list_content[i] = arr[arr.index(list_content[i]) + 1]
    return list_content

def signal_handler(signal, frame):
    print 'You pressed Ctrl+C!'
    print 'currently verify ' + str(index) + ': ' + digToStr(index)
    sys.exit(0)

signal.signal(signal.SIGINT, signal_handler)

# Choose one of them below as starting point
list_content = list(digToStr(index))
# list_content = list(start_content)

while True:
    if max_len < len(list_content):
        max_len = len(list_content)
        print 'search length ' + str(max_len)
    content = "".join(list_content)
    m = md5.new(content)
    m_hex = m.hexdigest()
    # print m_hex
    for i in xrange(0, len(m_hex), 2):
        if m_hex[i : i+2] == "27":
            if (((m_hex[i+2 : i+4] == "6f" or
                  m_hex[i+2 : i+4] == "4f") and
                 (m_hex[i+4 : i+6] == "72" or
                  m_hex[i+4 : i+6] == "52")) or m_hex[i+2 : i+6] == "7c7c") and m_hex[i+6 : i+8] == "27":
                if (m_hex[i+8 : i+10] == "31" or
                    m_hex[i+8 : i+10] == "32" or
                    m_hex[i+8 : i+10] == "33" or
                    m_hex[i+8 : i+10] == "34" or
                    m_hex[i+8 : i+10] == "35" or
                    m_hex[i+8 : i+10] == "36" or
                    m_hex[i+8 : i+10] == "37" or
                    m_hex[i+8 : i+10] == "38" or
                    m_hex[i+8 : i+10] == "39"):
                    print content
                    print m.digest()
                    raw_input("")
            elif m_hex[i+2 : i+6] == "7c7c":
                if m_hex[i+8 : i+12] == "3b23" and (m_hex[i+6 : i+8] == "31" or
                                                    m_hex[i+6 : i+8] == "32" or
                                                    m_hex[i+6 : i+8] == "33" or
                                                    m_hex[i+6 : i+8] == "34" or
                                                    m_hex[i+6 : i+8] == "35" or
                                                    m_hex[i+6 : i+8] == "36" or
                                                    m_hex[i+6 : i+8] == "37" or
                                                    m_hex[i+6 : i+8] == "38" or
                                                    m_hex[i+6 : i+8] == "39"):
                    print content
                    print m.digest()
                    raw_input("")
    index += 1
    list_content = addOne(list_content)
    print str(index) + ": " + content
